# Protractor-Cucumber
 Protractor, an end-to-end testing framework, supports Jasmine and is specifically built for AngularJS applications. It is highly flexible with different Behavior-Driven Development (BDD) frameworks such as Cucumber. It allows writing specifications based on the behavior of the application.
