var {setDefaultTimeout} = require('@cucumber/cucumber');

setDefaultTimeout(30 * 1000);